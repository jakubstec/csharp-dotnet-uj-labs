namespace labs01;

public enum EHeroClass
{
    Barbarzynca,
    Paladyn,
    Amazonka
}