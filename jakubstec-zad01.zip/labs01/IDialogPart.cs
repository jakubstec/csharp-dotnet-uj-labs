namespace labs01;

public interface IDialogPart
{
    string Content { get; }
}