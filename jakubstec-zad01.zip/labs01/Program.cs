﻿// See https://aka.ms/new-console-template for more information
namespace labs01;
    
public class Program
{
    static void Main()
    {
        Game g = new Game();
        g.GameLoop();
    }
}